1. Abrir terminal.
2. Introducir comando: java -jar 'path CompiladorG15.jar' 'path codigo fuente'
3. Al finalizar la ejecución, se mostraran los resultados y se generaran archivos .txt con dichos resultados.


+ Nota: Se requiere minimamente el JRE8 para poder ejecutar el .jar.
+ Nota2: En caso de que ocurra un fallo de escritura al finalizar la compilación, los resultados se mostraran a través de la terminal.
+ Nota3: En la carpeta 'casos_prueba' estan los distintos casos de prueba estipulados por la cátedra.
