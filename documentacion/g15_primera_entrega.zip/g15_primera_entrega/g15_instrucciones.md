Importante: El archivo 'g15_compilador.zip' es el ejecutable del compilador. Para ejecutarlo, cambiarle la extension a '.jar'.

1. Abrir terminal.
2. Introducir comando: java -jar 'path g15_compilador.jar' 'path codigo fuente'
3. Al finalizar la ejecución, se mostraran los resultados y se generaran archivos .txt con dichos resultados.

+ Nota: Se requiere minimamente el JRE8 para poder ejecutar el .jar.
+ Nota2: En la carpeta 'casos_prueba' estan los distintos casos de prueba estipulados por la cátedra.
