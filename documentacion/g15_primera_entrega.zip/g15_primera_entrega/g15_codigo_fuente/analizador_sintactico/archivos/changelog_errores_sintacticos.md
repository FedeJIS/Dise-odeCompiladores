+ Lista de variables sin ';'.
+ Procedimientos sin ';'.
+ Asignaciones sin ';'.
+ Invocaciones sin ';'.
+ Loops sin ';'.
+ Prints sin ';'.
+ Ifs sin ';'.
+ Ifs sin IF.
+ Ifs sin condicion.
+ Ifs sin THEN.
+ Ifs con cuerpo THEN vacio.
+ Ifs con cuerpo ELSE vacio.
+ Ifs sin END_IF.

#########################################

+ Loops sin condicion.
+ Loops sin cuerpo.
+ Asignaciones sin expresion.
+ Invocaciones de procedimientos sin parentesis de cierre.

#########################################

+ Declaracion de procs sin nombre.
+ Declaracion de procs sin parentesis de cierre en parametros.
+ Declaracion de procs sin NI. (Se puede mejorar usando token 'error').
+ Declaracion de procs con mas de 3 parametros. (Ver si se puede emprolijar la gramatica).
- NO DETECTA FALTANTE DE ';' EN UNA SENTENCIA SIN LLAVES DENTRO DEL CUERPO.
- REGLA PARA DETECTAR FALTANTE DE '}' DE CIERRE GENERA UN CONFLICTO SHIFT/REDUCE.



 
 